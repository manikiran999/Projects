﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hexad.BakeryApp.Parsers
{
    public static class ArgumentParser
    {
        /// <summary>
        /// Processes each argument/order line provided by user into valid item & quantity pair.
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static OrderRequestModel ProcessArgument(string input)
        {
            if (!string.IsNullOrWhiteSpace(input))
            {
                input = input.Trim();
                var parts = input.Split(' ');
                if (parts.Length == 2)
                {
                    var model = new OrderRequestModel();
                    model.Quantity = Convert.ToInt32(parts[0]);
                    model.ProductCode = Convert.ToString(parts[1]);
                    return model;
                }
            }
            return null;
        }
    }
}
