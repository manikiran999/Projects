﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hexad.BakeryApp
{
    public class OrderRequestModel
    {
        public int Quantity { get; set; }
        public string ProductCode { get; set; }
    }    
}
