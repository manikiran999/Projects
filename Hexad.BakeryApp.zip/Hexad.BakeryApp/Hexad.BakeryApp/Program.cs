﻿using Hexad.BakeryApp.Abstraction.Abstracts;
using Hexad.BakeryApp.Concrete.Concrete;
using Hexad.BakeryApp.Entities.Models;
using Hexad.BakeryApp.Parsers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hexad.BakeryApp
{
    public class Program
    {
        public static List<OrderLineItemModel> resultList = new List<OrderLineItemModel>();
        static void Main(string[] args)
        {
            IProductManager productManager = new ProductManager();
            IPackBreakdownManager packBreakdownManager = new PackBreakdownManager();
            Console.WriteLine("Welcome to Hexad Bakery App");

            Console.Write("How many products do you want to add to this order:");
            int inputProductCount = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < inputProductCount; i++)
            {
                var orderLine = ArgumentParser.ProcessArgument(Console.ReadLine());
                if (orderLine != null)
                {
                    var product = productManager.GetProductByCode(orderLine.ProductCode);
                    var packs = product.Packs.Select(d => d.Quantity).ToArray();

                    var resultset = new List<OrderLineItemModel>();
                    packBreakdownManager.GetPackCostBreakdown(orderLine.Quantity, packs, ref resultset);
                    resultset.ForEach(item =>
                    {
                        item.Quantity = orderLine.Quantity;
                        item.ProductCode = orderLine.ProductCode;
                        var productPack = product.Packs.FirstOrDefault(d => d.Quantity == item.PackSize);
                        if (productPack != null)
                        {
                            item.Price = productPack.ComboPrice;
                        }
                    });
                    var filteredList = resultset.Where(d => d.PackQuantity > 0).ToList();
                    resultList.AddRange(filteredList.GetRange(0, filteredList.Count).ToList());
                }
            }
            if (resultList.Any())
            {
                Console.WriteLine();
                var query = from c in resultList
                            group c by new
                            {
                                c.Quantity,
                                c.ProductCode
                            } into gcs
                            select new
                            {
                                Quantity = gcs.Key.Quantity,
                                ProductCode = gcs.Key.ProductCode,
                                TotalPrice = gcs.Sum(l => l.Price * l.PackQuantity),
                                Details = gcs.ToList()
                            };
                query.ToList().ForEach(item =>
                {
                    Console.WriteLine(string.Format("{0} {1} ${2}", item.Quantity, item.ProductCode, item.TotalPrice));
                    item.Details.ForEach(detail =>
                    {
                        Console.WriteLine(string.Format("\t{0} X {1} ${2}", detail.PackQuantity, detail.PackSize, detail.Price));
                    });
                });
            }
            Console.ReadLine();
        }
    }
}
