﻿using Hexad.BakeryApp.Abstraction.Abstracts;
using Hexad.BakeryApp.Entities.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hexad.BakeryApp.Concrete.Concrete
{
    public class ProductManager : IProductManager
    {
        //prepare the products as per the given requirement
        static List<Product> products = new List<Product>()
        {
            new Product() {
                Id = 1111, 
                Name = "Vegemite Scroll", 
                Description = "Vegemite Scroll", 
                Code = "VS5", 
                BasePrice = 0.0M, 
                CreatedBy = 1010, 
                ModifiedBy =1010, 
                CreatedOn = DateTime.Now, 
                ModifiedOn = DateTime.Now, 
                Packs = new List<ProductPack>() {
                    new ProductPack() { Id = 6161, ProductId = 1111, Quantity = 3, ComboPrice = 6.99M, PackName = "3 pack", CreatedBy = 1010, ModifiedBy = 1010, CreatedOn = DateTime.Now, ModifiedOn = DateTime.Now},
                    new ProductPack() { Id = 7171, ProductId = 1111, Quantity = 5, ComboPrice = 8.99M, PackName = "5 pack", CreatedBy = 1010, ModifiedBy = 1010, CreatedOn = DateTime.Now, ModifiedOn = DateTime.Now}
                }
            },
            new Product() {Id = 2222, Name = "Blueberry Muffin", Description = "Blueberry Muffin", Code = "MB11", BasePrice = 0.0M, CreatedBy = 1010, ModifiedBy =1010, CreatedOn = DateTime.Now, ModifiedOn = DateTime.Now, 
                Packs = new List<ProductPack>() {
                    new ProductPack() { Id = 6262, ProductId = 2222, Quantity = 2, ComboPrice = 9.95M, PackName = "2 pack", CreatedBy = 1010, ModifiedBy = 1010, CreatedOn = DateTime.Now, ModifiedOn = DateTime.Now},
                    new ProductPack() { Id = 7272, ProductId = 2222, Quantity = 5, ComboPrice = 16.95M, PackName = "5 pack", CreatedBy = 1010, ModifiedBy = 1010, CreatedOn = DateTime.Now, ModifiedOn = DateTime.Now},
                    new ProductPack() { Id = 8282, ProductId = 2222, Quantity = 8, ComboPrice = 24.95M, PackName = "8 pack", CreatedBy = 1010, ModifiedBy = 1010, CreatedOn = DateTime.Now, ModifiedOn = DateTime.Now}

                }},
            new Product() {Id = 3333, Name = "Croissant", Description = "Croissant", Code = "CF", BasePrice = 0.0M, CreatedBy = 1010, ModifiedBy =1010, CreatedOn = DateTime.Now, ModifiedOn = DateTime.Now, 
                Packs = new List<ProductPack>() {
                    new ProductPack() { Id = 6363, ProductId = 3333, Quantity = 3, ComboPrice = 5.95M, PackName = "3 pack", CreatedBy = 1010, ModifiedBy = 1010, CreatedOn = DateTime.Now, ModifiedOn = DateTime.Now},
                    new ProductPack() { Id = 7373, ProductId = 3333, Quantity = 5, ComboPrice = 9.95M, PackName = "5 pack", CreatedBy = 1010, ModifiedBy = 1010, CreatedOn = DateTime.Now, ModifiedOn = DateTime.Now},
                    new ProductPack() { Id = 8383, ProductId = 3333, Quantity = 9, ComboPrice = 16.99M, PackName = "9 pack", CreatedBy = 1010, ModifiedBy = 1010, CreatedOn = DateTime.Now, ModifiedOn = DateTime.Now}

                }}
        };



        public IEnumerable<Product> GetProducts()
        {
            return products;
        }

        public Product GetProductById(int productId)
        {
            return products.FirstOrDefault(d => d.Id == productId);
        }

        public Product GetProductByCode(string productCode)
        {
            return products.FirstOrDefault(d => string.Equals(d.Code.ToLower(), productCode.ToLower()));
        }
    }
}
