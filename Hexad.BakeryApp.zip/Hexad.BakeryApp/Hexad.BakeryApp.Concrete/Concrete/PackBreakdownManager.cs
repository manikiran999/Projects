﻿using Hexad.BakeryApp.Abstraction.Abstracts;
using Hexad.BakeryApp.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hexad.BakeryApp.Concrete.Concrete
{
    public class PackBreakdownManager : IPackBreakdownManager
    {
        public int GetPackCostBreakdown(int totalQuantity, int[] availablePacks, ref List<OrderLineItemModel> resultSet)
        {
            if (!availablePacks.Any())
            {
                return -1;
            }

            var sortedAvailablePacks = availablePacks.OrderByDescending(d => d);
            var highestQunatityPack = sortedAvailablePacks.First();
            if (totalQuantity >= highestQunatityPack)
            {
                var quantity = totalQuantity / highestQunatityPack;
                resultSet.Add(new OrderLineItemModel() { PackSize = highestQunatityPack, PackQuantity = quantity });

                totalQuantity = totalQuantity - (quantity * highestQunatityPack);
            }
            else if (availablePacks.Length == 1)
            {
                return 1;
            }
            if (totalQuantity == 0)
            {
                return 0;
            }
            var latestAvailablePacks = new int[] { highestQunatityPack };
            var retVal = this.GetPackCostBreakdown(totalQuantity, sortedAvailablePacks.Except(latestAvailablePacks).ToArray(), ref resultSet);
            if (retVal == 1 || retVal == -1)
            {
                var model = resultSet.FirstOrDefault(h => h.PackSize == highestQunatityPack);
                if (model != null)
                {
                    model.PackQuantity = model.PackQuantity - 1;
                    totalQuantity = totalQuantity + model.PackSize * 1;
                    if (sortedAvailablePacks.Except(latestAvailablePacks).Any())
                        return this.GetPackCostBreakdown(totalQuantity, sortedAvailablePacks.Except(latestAvailablePacks).ToArray(), ref resultSet);
                }
            }
            return retVal;
        }
    }
}
