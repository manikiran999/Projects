﻿using Hexad.BakeryApp.Abstraction.Abstracts;
using Hexad.BakeryApp.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hexad.BakeryApp.Concrete.Concrete
{
    public class PackBreakdownManager : IPackBreakdownManager
    {
        public int GetPackCostBreakdown(int totalQuantity, int[] availablePacks, ref List<OrderLineItemModel> resultSet)
        {
            if (!availablePacks.Any())
            {
                return -1;
            }
            //sort the available packs by descending order so that, we process them by highest pack
            var sortedAvailablePacks = availablePacks.OrderByDescending(d => d).ToList();
            var highestQunatityPack = sortedAvailablePacks.First();

            if (totalQuantity >= highestQunatityPack)
            {
                //check for how many highest quantity packs adjustable for the order
                var quantity = totalQuantity / highestQunatityPack;
                resultSet.Add(new OrderLineItemModel() { PackSize = highestQunatityPack, PackQuantity = quantity });

                totalQuantity = totalQuantity - (quantity * highestQunatityPack);
            }
            else if (availablePacks.Length == 1)
            {
                return 1;
            }
            if (totalQuantity == 0)
            {
                return 0;
            }
            var latestAvailablePacks = new int[] { highestQunatityPack };
            //process it recursively for remaining quatities
            var retVal = this.GetPackCostBreakdown(totalQuantity,
                sortedAvailablePacks.Except(latestAvailablePacks).ToArray(), ref resultSet);
            //if there is no available packs or only one available pack, we need to reprocess them again.
            if (retVal == 1 || retVal == -1)
            {
                var model = resultSet.FirstOrDefault(h => h.PackSize == highestQunatityPack);
                if (model != null)
                {
                    //traversing back as we did not get the optimum solution for a given quantity
                    model.PackQuantity = model.PackQuantity - 1;
                    totalQuantity = totalQuantity + model.PackSize * 1;
                    if (sortedAvailablePacks.Except(latestAvailablePacks).Any())
                    {
                        return this.GetPackCostBreakdown(totalQuantity, sortedAvailablePacks.Except(latestAvailablePacks).ToArray(), ref resultSet);
                    }
                    else if ((totalQuantity - model.PackSize * 1) < highestQunatityPack)
                    {
                        resultSet.ForEach(result =>
                        {
                            totalQuantity += result.PackSize * result.PackQuantity;
                        });
                        if (totalQuantity % highestQunatityPack == 0)
                        {
                            resultSet = new List<OrderLineItemModel>();
                            return this.GetPackCostBreakdown(totalQuantity, (latestAvailablePacks).ToArray(), ref resultSet);
                        }
                    }
                }
            }
            return retVal;
        }
    }
}
