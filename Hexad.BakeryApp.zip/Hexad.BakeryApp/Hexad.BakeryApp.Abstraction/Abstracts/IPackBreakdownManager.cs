﻿using Hexad.BakeryApp.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hexad.BakeryApp.Abstraction.Abstracts
{
    public interface IPackBreakdownManager
    {
        int GetPackCostBreakdown(int totalQuantity, int[] availablePacks, ref List<OrderLineItemModel> resultset);
    }
}
