﻿using Hexad.BakeryApp.Entities.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hexad.BakeryApp.Abstraction.Abstracts
{
    public interface IProductManager
    {
        IEnumerable<Product> GetProducts();
        Product GetProductById(int productId);
        Product GetProductByCode(string productCode);

    }
}
