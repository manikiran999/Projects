﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Hexad.BakeryApp.Concrete.Concrete;
using Hexad.BakeryApp.Entities.Models;
using System.Collections.Generic;
using System.Linq;

namespace Hexad.BakeryAPP.UnitTests
{
    [TestClass]
    public class PackBreakdownTests
    {
        [TestMethod]
        public void PackBreakdown_When_Customer_Asks_Quantity_SameAsPackSize_For_VegemiteScroll()
        {
            var manager = new PackBreakdownManager();
            var resultset = new List<OrderLineItemModel>();
            manager.GetPackCostBreakdown(5, new int[] { 3, 5 }, ref resultset);
            Assert.IsTrue(ValidateResult(5, resultset));
        }

        [TestMethod]
        public void PackBreakdown_When_Customer_Asks_Quantity_MoreThanPackSize_For_VegemiteScroll()
        {
            var manager = new PackBreakdownManager();
            var resultset = new List<OrderLineItemModel>();
            manager.GetPackCostBreakdown(20, new int[] { 3, 5 }, ref resultset);
            Assert.IsTrue(ValidateResult(20, resultset));
        }

        [TestMethod]
        public void PackBreakdown_When_Customer_Asks_Quantity_ForAnySizepack_For_VegemiteScroll()
        {
            var manager = new PackBreakdownManager();
            var resultset = new List<OrderLineItemModel>();
            manager.GetPackCostBreakdown(12, new int[] { 3, 5 }, ref resultset);
            Assert.IsTrue(ValidateSinglePackSize(4, 3, resultset));
            Assert.IsTrue(ValidateSinglePackSize(0, 5, resultset));
        }

        [TestMethod]
        public void PackBreakdown_When_Customer_Asks_Quantity_SameAsPackSize_For_BlueberryMuffin()
        {
            var manager = new PackBreakdownManager();
            var resultset = new List<OrderLineItemModel>();
            manager.GetPackCostBreakdown(8, new int[] { 2, 5, 8}, ref resultset);
            Assert.IsTrue(ValidateResult(8, resultset));
        }

        [TestMethod]
        public void PackBreakdown_When_Customer_Asks_Quantity_MoreThanPackSize_For_BlueberryMuffin()
        {
            var manager = new PackBreakdownManager();
            var resultset = new List<OrderLineItemModel>();
            manager.GetPackCostBreakdown(20, new int[] { 2, 5, 8 }, ref resultset);
            Assert.IsTrue(ValidateResult(20, resultset));
        }

        [TestMethod]
        public void PackBreakdown_When_Customer_Asks_Quantity_ForAnySizepack_For_BlueberryMuffin()
        {
            var manager = new PackBreakdownManager();
            var resultset = new List<OrderLineItemModel>();
            manager.GetPackCostBreakdown(20, new int[] { 2, 5, 8 }, ref resultset);
            Assert.IsTrue(ValidateSinglePackSize(2, 2, resultset));
            Assert.IsTrue(ValidateSinglePackSize(0, 5, resultset));
            Assert.IsTrue(ValidateSinglePackSize(2, 8, resultset));
        }

        [TestMethod]
        public void PackBreakdown_When_Customer_Asks_Quantity_SameAsPackSize_For_Croissant()
        {
            var manager = new PackBreakdownManager();
            var resultset = new List<OrderLineItemModel>();
            manager.GetPackCostBreakdown(3, new int[] { 3, 5, 9 }, ref resultset);
            Assert.IsTrue(ValidateResult(3, resultset));
        }

        [TestMethod]
        public void PackBreakdown_When_Customer_Asks_Quantity_MoreThanPackSize_For_Croissant()
        {
            var manager = new PackBreakdownManager();
            var resultset = new List<OrderLineItemModel>();
            manager.GetPackCostBreakdown(18, new int[] { 3, 5, 9 }, ref resultset);
            Assert.IsTrue(ValidateResult(18, resultset));
        }
        [TestMethod]
        public void PackBreakdown_When_Customer_Asks_Quantity_ForAnySizepack_For_Croissant()
        {
            var manager = new PackBreakdownManager();
            var resultset = new List<OrderLineItemModel>();
            manager.GetPackCostBreakdown(20, new int[] { 3, 5, 9 }, ref resultset);
            Assert.IsTrue(ValidateSinglePackSize(2, 3, resultset));
            Assert.IsTrue(ValidateSinglePackSize(1, 5, resultset));
            Assert.IsTrue(ValidateSinglePackSize(1, 9, resultset));
        }
        private bool ValidateResult(int inputTotalQunatity, List<OrderLineItemModel> resultSet)
        {
            if (resultSet.Any())
            {
                return inputTotalQunatity == (resultSet.Sum(d => d.PackSize * d.PackQuantity));
            }
            return false;
        }

        private bool ValidateSinglePackSize(int noOfPacks, int packSize, List<OrderLineItemModel> resultSet)
        {
            if (resultSet.Any())
            {
                return noOfPacks == (resultSet.FirstOrDefault(d => d.PackSize == packSize) == null? 0: resultSet.FirstOrDefault(d => d.PackSize == packSize).PackQuantity);
            }
            return false;
        }
    }
}
