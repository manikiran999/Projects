﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Hexad.BakeryApp.Concrete.Concrete;
using Hexad.BakeryApp.Entities.Models;
using System.Collections.Generic;
using System.Linq;

namespace Hexad.BakeryAPP.UnitTests
{
    [TestClass]
    public class PackBreakdownTests
    {
        [TestMethod]
        public void PackBreakdown_When_Customer_Asks_Quantity_SameAsPackSize()
        {
            var manager = new PackBreakdownManager();
            var resultset = new List<OrderLineItemModel>();
            manager.GetPackCostBreakdown(5, new int[] { 3, 5 }, ref resultset);
            Assert.IsTrue(ValidateResult(5, resultset));
        }

        private bool ValidateResult(int inputTotalQunatity, List<OrderLineItemModel> resultSet)
        {
            if (resultSet.Any())
            {
                return inputTotalQunatity == (resultSet.Sum(d => d.PackSize * d.PackQuantity));
            }
            return false;
        }
    }
}
