﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hexad.BakeryApp.Entities.BusinessObjects
{
    public class Product : BaseHexadEntity
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string Code { get; set; }
        public decimal BasePrice { get; set; }
        public List<ProductPack> Packs { get; set; }
    }
}
