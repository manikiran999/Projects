﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hexad.BakeryApp.Entities.BusinessObjects
{
    public class ProductPack : BaseHexadEntity
    {
        public int ProductId { get; set; }
        public string PackName { get; set; }
        public int Quantity { get; set; }
        public decimal ComboPrice { get; set; }
    }
}
